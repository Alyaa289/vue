export default [
    {
        id: 15,
        name: "Heba",
        city: "Assuit"
    },
    {
        id: 116,
        name: "Mona",
        city: "Assuit"
    },
    {
        id: 17,
        name: "Israa",
        city: "Cairo"
    },
    {
        id: 18,
        name: "Hager",
        city: "Minya"
    },
    {
        id: 19,
        name: "Ahmed",
        city: "Sohag"
    },
    {
        id: 20,
        name: "Abdo",
        city: "Alex"
    }
]