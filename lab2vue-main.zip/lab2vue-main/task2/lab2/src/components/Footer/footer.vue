<template>
    <div class="col-12 bg-primary-subtle h-25 p-2">
    <div class="text-center ">  © ITI - All Rights Reserved</div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>