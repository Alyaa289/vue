<template>
  <ul class="list-group " >
    <li class="list-group"><a href="#">Home</a></li>
    <li class="list-group"><a href="#">About</a></li>
    <li class="list-group"><a href="#">Contect</a></li>
    <li class="list-group"><a href="#">Gallery</a></li>
  </ul>
</template>

<script>
export default {

}
</script>

<style>

</style>