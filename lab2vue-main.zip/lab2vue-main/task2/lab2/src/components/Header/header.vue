<template>
  <div class="col-12 bg-primary-subtle h-25">
    <h1 class="text-center">Welcome </h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>