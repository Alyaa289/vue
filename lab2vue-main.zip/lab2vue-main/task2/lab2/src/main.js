import { createApp } from 'vue'
import App from './App.vue'
import main from './main.vue'
createApp(main).mount('#app')
