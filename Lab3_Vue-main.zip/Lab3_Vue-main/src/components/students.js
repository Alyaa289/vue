export default [
  {
    id: 1,
    name: "Ali",
    city: "Cairo"
  },
  {
    id: 2,
    name: "Sara",
    city: "Alexandria"
  },
  {
    id: 3,
    name: "Omar",
    city: "Giza"
  },
  {
    id: 4,
    name: "Laila",
    city: "Mansoura"
  }
];
