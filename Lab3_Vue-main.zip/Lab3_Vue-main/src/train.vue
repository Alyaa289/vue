<template>
 <div>
    <Trainee/>
 </div>
</template>

<script>
import Trainee from "./components/trainee.vue"
export default{
    components:{
        Trainee,
    }
}
</script>

<style>
</style>

